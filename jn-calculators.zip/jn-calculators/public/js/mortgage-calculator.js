$ = jQuery;

$(document).ready(function(){

    renderMortgageHtml();
    detectMortgageChanges();
    calculateMortgageSummary();
});


function renderMortgageHtml(){
    var prepended = "";
    prepended += generateInputSlider("#mortage-inputs","mortgage-amount","Home Price","100000","50000000","10000","15000000","$");
    prepended += generateInputSlider("#mortage-inputs","down-payment-amount","Down Payment","0","50000000","10000","1500000","$");
    prepended += generateInputSlider("#mortage-inputs","mortgage-interest-rate","Interest Rate","0.1","100","0.1","8","%");
    prepended += generateInputSlider("#mortage-inputs","mortgage-length","Loan Period","1","50","1","25","Years");
    $("#mortage-inputs").prepend(prepended);

    var appended = "";
    appended += generateInputSlider("#mortage-inputs","nht-loan-amount","NHT Loan Amount","100000","50000000","10000","5500000","$");
    appended += generateInputSlider("#mortage-inputs","nht-loan-interest-rate","NHT Interest Rate","0.1","100","0.1","6","%");
    $(".nht").append(appended);
}


//Listen for changes on mortgage container
function detectMortgageChanges(){
    $(".mortgage-container").change(function(){
        calculateMortgageSummary();
    })
}


//TODO: THIS NEEDS TO BE SIMPLIFIED
function calculateMortgageSummary(){
    var mortgageSummary = {
        monthlyPayment: 0,
        interestPaid: 0,
        totalPaid: 0
    }
    var principal = $("#mortgage-amount-input").val();
    var downpayment = $("#down-payment-amount-input").val();
    var interestRate = $("#mortgage-interest-rate-input").val()/100;
    // interestRate = parseFloat(interestRate).toFixed(2);
    var loanTerm = $("#mortgage-length-input").val();
    var nhtAmount = parseFloat($("#nht-loan-amount-input").val());
    var nhtInterest =$("#nht-loan-interest-rate-input").val()/100;
    
    var isNhtActive = false;

    if($("#applyNht").is(":checked")){
        $(".nht").fadeIn();
        isNhtActive = true;
    }else{
        $(".nht").fadeOut();
        isNhtActive = false;
    }

    if(parseFloat(downpayment) > parseFloat(principal)){
        $("#down-payment-amount-error").text("Down Payment cannot be higher than the price of the Home");
        $("#down-payment-amount-error").removeClass("hidden");
        return false;
    }else{
        $("#down-payment-amount-error").addClass("hidden");
    }

    if(isNhtActive == true){
        if(parseFloat(nhtAmount) > parseFloat(principal)){
            $("#nht-loan-amount-error").text("NHT loan amount cannot be higher than the price of the Home");
            $("#nht-loan-amount-error").removeClass("hidden");
            return false;
        }else{
            $("#nht-loan-amount-error").addClass("hidden");
        }
    }



    if(downpayment == 0){
        if(isNhtActive == true){
            mortgageSummary.monthlyPayment = findMortgageWithDownpayment((principal-nhtAmount),downpayment,interestRate,loanTerm);
            mortgageSummary.monthlyPayment += findMortgageWithoutDownpayment(nhtAmount,nhtInterest,loanTerm);
        }else{
            mortgageSummary.monthlyPayment = findMortgageWithoutDownpayment(principal,interestRate,loanTerm);
        }
    }else{

        if(isNhtActive == true){
            mortgageSummary.monthlyPayment = findMortgageWithDownpayment((principal-nhtAmount),downpayment,interestRate,loanTerm);
            mortgageSummary.monthlyPayment += findMortgageWithoutDownpayment(nhtAmount,nhtInterest,loanTerm);
        
        }else{
            mortgageSummary.monthlyPayment = findMortgageWithDownpayment(principal,downpayment,interestRate,loanTerm);
        }
    }
    

    var total = parseFloat(principal) - parseFloat(downpayment);
    if(isNhtActive == true){
        // total +=  parseFloat(nhtAmount);
    }

    mortgageSummary.interestPaid = ((mortgageSummary.monthlyPayment*(loanTerm*12)) - principal);
    $(".table-mortgage-total-amount").text(dollarFormat(total));
    $("#mortgage-monthly-payment").text(dollarFormat(mortgageSummary.monthlyPayment));
    $(".table-mortgage-interest-paid").text(dollarFormat(mortgageSummary.interestPaid));
    $(".table-mortgage-rate").text($("#mortgage-interest-rate-input").val() + "%");
    $(".table-mortgage-payment-length").text(loanTerm*12);

    destroyMortgageChart();
   renderMortgageChart(principal,mortgageSummary.interestPaid);
}


//Calculate mortage payment function
function findMortgageWithoutDownpayment(principal, rate, time) {
    //using formula P * ((rate(1+rate)^nt)/(1+rate)^nt - 1)
    var numerator = 0;
    var denominator = 0;
    rate = rate/12;
    numerator = rate * (Math.pow(1+rate,time*12));
    denominator = (Math.pow(1+rate,time*12) - 1);
    var payment = principal*(numerator/denominator);
    return payment;
}

function findMortgageWithDownpayment(principal,downpayment,rate,time){
    //using formula (P * (rate/12))/ ( 1 - ( 1+ rate/12)^-nt)
    var numerator = 0;
    var denominator = 0;
    var payment = 0;
    numerator = (principal-downpayment) * (rate/12);
    denominator = 1 - Math.pow(1+(rate/12),-time*12);
    payment = numerator/denominator;
    return payment;
}

//TODO CREATE AMORTIZATION SCHEDULE
function calculateAmoritizationSchedule(principal,rate,time){

}



function destroyMortgageChart(){
    $("#mortgagePieChart").remove();
    $("iframe").remove();
    $("#mortgage-chart-container").append('<canvas id="mortgagePieChart"></canvas>')
 
 }

//Render the Mortgage Chart
function renderMortgageChart(principal,interest){
    
    principal = parseFloat(principal).toFixed(2);
    interest = parseFloat(interest).toFixed(2);
    //TODO: FIX THIS SO IT DOESN'T REQUIRE A TIMEOUT
    setTimeout(()=> {
        var ctx = document.getElementById('mortgagePieChart').getContext('2d');

        var mortgagePieChart = new Chart(ctx,{
            type: 'pie',
            data: {
                datasets: [{
                    data: [principal,interest],
                    backgroundColor: ["#2196F3", "#FF5722"]
                }],
                labels: [
                    'Principal',
                    'Interest'
                ]
            }
        });
    },0.00001)
   
}
