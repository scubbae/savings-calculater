var hasClicked = false;
$ = jQuery;
// (function( $ ) {
// 	'use strict';

	$(document).ready(function(){
        loadCalculator();
        toggleInfo();
    })
    
    // $(document).on("mobileinit", function(){
    //     loadCalculator();
    // })

// })( jQuery );


function loadCalculator(calculatorName){ 
    $ = jQuery;
    var pathToTemplates = WPURLS.plugin_url + "/public/partials/";

   
  
    switch(calculatorName){
        case "mortgage":
            $("#calculator-container").load(pathToTemplates + "mortgage-calculator.php",function(response, status, xhr){
                // console.log(response);
                // console.log(status);
                // console.log(xhr);
                
                setToActive($("#mortgage-icon"))
            });
            break;
        
        case "savings":
            $("#calculator-container").load(pathToTemplates + "savings-calculator.php",function(){
                setToActive($("#savings-icon"))
            });
            break;
        
        case "loans":
            $("#calculator-container").load(pathToTemplates + "loan-calculator.php",function(){
                setToActive($("#loans-icon"));
            });
            break;

        case "goal":
            $("#calculator-container").load(pathToTemplates + "goal-calculator.php",function(){
                setToActive($("#goal-icon"))
            });
            break;
           

        default:
            $("#calculator-container").load(pathToTemplates+"mortgage-calculator.php",function(){
                setToActive($("#mortgage-icon"))
            });
            break;
            
    }

    if(hasClicked){
        $([document.documentElement, document.body]).animate({
            scrollTop: $("#calculator-container").offset().top
        }, 1000);
    }

    hasClicked = true;

    
   
}


function setToActive($element){
    $(".calculator-circle").removeClass('active');
    $element.addClass("active");
}



//Return numeric value as dollar in dollar formatting
function dollarFormat(value){
    floatValue = parseFloat(value).toFixed(2)
    return "$"+floatValue.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}


function generateInputSlider(container,id,name,min,max,step,defaultValue,type){

    // console.log("ID: " + id + "\n" + "Type: " + type);

    var builder = "";
    builder += '<div id="'+id+'-container" class="form-group">';
    builder += '<div class="row">';
    builder += '<div class="col-md-5">';
    if(type != "date"){
        builder += '<label class="calc-label">'+name+' ('+type+')</label>';
    }else{
        builder += '<label class="calc-label">'+name+'</label>';
    }
        builder += '</div>';

    if( type =="date" ){
        builder += '<div class="col-md-3">';
        builder += '<input value="'+defaultValue+'" id="'+id+'-input" max="'+max+'" min="'+min+'" step="'+step+'" class="form-control calc-input" type="number">';
        builder += '</div>';
        builder += '<div class="col-md-4">';
        builder += '<select id="'+id+'-select" class="form-control calc-input"><option value="0">Years</option> <option value="1">Months</option></select>';
        builder += '</div>';
    }else{
        builder += '<div class="col-md-7">';
        builder += '<input value="'+defaultValue+'" id="'+id+'-input" max="'+max+'" min="'+min+'" step="'+step+'" class="form-control calc-input" type="number">';
        builder += '</div>';
    }
    builder += '</div>';
    builder += '<div class="row">';
    builder += '<input value="'+defaultValue+'" min="'+min+'" max="'+max+'" step="'+step+'" type="range" class="slider" id="'+id+'-slider">';
    builder += '</div>';
    builder += '<div role="alert" class="alert alert-danger hidden" id="'+id+'-error"></div>';
    builder += '</div>';
    mapSliderToInput(container,"#"+id+"-slider","#"+id+"-input",type);
    return builder;
}



//Map a slider to an input value
function mapSliderToInput(container,slider,input,type){
    $(container).on('input change', input, function(){
        $(slider).val($(this).val());
    });

    $(container).on('input change', slider, function(){
        $(input).val($(this).val());   
     });
}

function toggleInfo(){
    $(".calculator-info").on("mouseover", function(){
        $(this).closest(".col-md-3").find(".extra-info").fadeIn();
    })

    $(".calculator-info").on("mouseout", function(){
        $(this).closest(".col-md-3").find(".extra-info").fadeOut();
    })
}