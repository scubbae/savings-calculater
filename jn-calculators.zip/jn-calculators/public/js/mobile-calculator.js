var hasClicked = false;
$ = jQuery;

$(document).ready(function(){
    renderAllHtml();
    loadView("mortgage");
    detectAllChanges();
    calculateMortgageSummary();
})

function loadView(viewName){
    $(".mobile .container-fluid").hide();
    $(".mobile ."+viewName+"-container").fadeIn();
    // alert("#"+viewName+"-icon")  
    setToActive("#"+viewName+"-icon")  
    detectAllChanges(true);

//     if(hasClicked){
//         $([document.documentElement, document.body]).animate({
//             scrollTop: $("#mobile-calculator-container").offset().top
//         }, 1000);
//     }

//     hasClicked = true;

}

function renderAllHtml(){
    $("#goal-inputs").append( generateInputSlider("#goal-inputs","target-amount","Target Amount","0","50000000","1","500000","$"));
    $("#goal-inputs").append( generateInputSlider("#goal-inputs","current-saved","Amount in Savings","0","50000000","1","0","$"));
    $("#goal-inputs").append( generateInputSlider("#goal-inputs","goal-annual-interest","Interest Rate","0","100","0.1","0","%"));
    $("#goal-inputs").append( generateInputSlider("#goal-inputs","goal-number-year","Length of Investment","1","50","1","5","date"));

    $("#loan-inputs").append( generateInputSlider("#loan-inputs","loan-amount","Loan Amount","0","50000000","10000","15000000","$"));
    $("#loan-inputs").append( generateInputSlider("#loan-inputs","loan-interest-rate","Loan Interest Rate","0.1","100",".1","8","%"));
    $("#loan-inputs").append( generateInputSlider("#loan-inputs","loan-term","Loan Term","1","50","1","5","date"));

    var prepended = "";
    prepended += generateInputSlider("#mortage-inputs","mortgage-amount","Home Price","100000","50000000","10000","15000000","$");
    prepended += generateInputSlider("#mortage-inputs","down-payment-amount","Down Payment","0","50000000","10000","1500000","$");
    prepended += generateInputSlider("#mortage-inputs","mortgage-interest-rate","Interest Rate","0.1","100","0.1","8","%");
    prepended += generateInputSlider("#mortage-inputs","mortgage-length","Loan Period","1","50","1","25","Years");
    $("#mortage-inputs").prepend(prepended);
    var appended = "";
    appended += generateInputSlider("#mortage-inputs","nht-loan-amount","NHT Loan Amount","100000","50000000","10000","5500000","$");
    appended += generateInputSlider("#mortage-inputs","nht-loan-interest-rate","NHT Interest Rate","0.1","100","0.1","6","%");
    $(".nht").append(appended);

    $("#savings-inputs").append( generateInputSlider("#savings-inputs","initial-amount","Starting Amount","0","50000000","1","500000","$"));
    $("#savings-inputs").append( generateInputSlider("#savings-inputs","deposit-amount","Monthly Deposit","0","50000000","1","10000","$"));
    $("#savings-inputs").append( generateInputSlider("#savings-inputs","annual-interest","Interest Rate","0","100","0.1","5","%"));
    $("#savings-inputs").append( generateInputSlider("#savings-inputs","number-year","Length of Investment","1","50","1","5","date"));

}


function setToActive(element){
    $(".calculator-circle").removeClass('active');
    $(element).addClass("active");
}


function detectAllChanges(forceRefresh=false){
    $(".container-fluid").change(function(){
        calculateMortgageSummary();
        calculateSavings();
        calculateLoanSummary();
        calculateTarget();
    })

    if(forceRefresh === true){
        calculateMortgageSummary();
        calculateSavings();
        calculateLoanSummary();
        calculateTarget();
    }

}



//TODO: THIS NEEDS TO BE SIMPLIFIED
function calculateMortgageSummary(){
    var mortgageSummary = {
        monthlyPayment: 0,
        interestPaid: 0,
        totalPaid: 0
    }
    var principal = $("#mortgage-amount-input").val();
    var downpayment = $("#down-payment-amount-input").val();
    var interestRate = $("#mortgage-interest-rate-input").val()/100;
    // interestRate = parseFloat(interestRate).toFixed(2);
    var loanTerm = $("#mortgage-length-input").val();
    var nhtAmount = parseFloat($("#nht-loan-amount-input").val());
    var nhtInterest =$("#nht-loan-interest-rate-input").val()/100;
    
    var isNhtActive = false;

    if($("#applyNht").is(":checked")){
        $(".nht").fadeIn();
        isNhtActive = true;
    }else{
        $(".nht").fadeOut();
        isNhtActive = false;
    }

    if(parseFloat(downpayment) > parseFloat(principal)){
        $("#down-payment-amount-error").text("Down Payment cannot be higher than the price of the Home");
        $("#down-payment-amount-error").removeClass("hidden");
        return false;
    }else{
        $("#down-payment-amount-error").addClass("hidden");
    }

    if(isNhtActive == true){
        if(parseFloat(nhtAmount) > parseFloat(principal)){
            $("#nht-loan-amount-error").text("NHT loan amount cannot be higher than the price of the Home");
            $("#nht-loan-amount-error").removeClass("hidden");
            return false;
        }else{
            $("#nht-loan-amount-error").addClass("hidden");
        }
    }



    if(downpayment == 0){
        if(isNhtActive == true){
            mortgageSummary.monthlyPayment = findMortgageWithDownpayment((principal-nhtAmount),downpayment,interestRate,loanTerm);
            mortgageSummary.monthlyPayment += findMortgageWithoutDownpayment(nhtAmount,nhtInterest,loanTerm);
        }else{
            mortgageSummary.monthlyPayment = findMortgageWithoutDownpayment(principal,interestRate,loanTerm);
        }
    }else{

        if(isNhtActive == true){
            mortgageSummary.monthlyPayment = findMortgageWithDownpayment((principal-nhtAmount),downpayment,interestRate,loanTerm);
            mortgageSummary.monthlyPayment += findMortgageWithoutDownpayment(nhtAmount,nhtInterest,loanTerm);
        
        }else{
            mortgageSummary.monthlyPayment = findMortgageWithDownpayment(principal,downpayment,interestRate,loanTerm);
        }
    }
    

    var total = parseFloat(principal) - parseFloat(downpayment);
    if(isNhtActive == true){
        // total +=  parseFloat(nhtAmount);
    }

    mortgageSummary.interestPaid = ((mortgageSummary.monthlyPayment*(loanTerm*12)) - principal);
    $(".table-mortgage-total-amount").text(dollarFormat(total));
    $("#mortgage-monthly-payment").text(dollarFormat(mortgageSummary.monthlyPayment));
    $(".table-mortgage-interest-paid").text(dollarFormat(mortgageSummary.interestPaid));
    $(".table-mortgage-rate").text($("#mortgage-interest-rate-input").val() + "%");
    $(".table-mortgage-payment-length").text(loanTerm*12);

    destroyMortgageChart();
   renderMortgageChart(principal,mortgageSummary.interestPaid);
}


//Calculate mortage payment function
function findMortgageWithoutDownpayment(principal, rate, time) {
    //using formula P * ((rate(1+rate)^nt)/(1+rate)^nt - 1)
    var numerator = 0;
    var denominator = 0;
    rate = rate/12;
    numerator = rate * (Math.pow(1+rate,time*12));
    denominator = (Math.pow(1+rate,time*12) - 1);
    var payment = principal*(numerator/denominator);
    return payment;
}

function findMortgageWithDownpayment(principal,downpayment,rate,time){
    //using formula (P * (rate/12))/ ( 1 - ( 1+ rate/12)^-nt)
    var numerator = 0;
    var denominator = 0;
    var payment = 0;
    numerator = (principal-downpayment) * (rate/12);
    denominator = 1 - Math.pow(1+(rate/12),-time*12);
    payment = numerator/denominator;
    return payment;
}

//TODO CREATE AMORTIZATION SCHEDULE
function calculateAmoritizationSchedule(principal,rate,time){

}



function destroyMortgageChart(){
    $("#mortgagePieChart").remove();
    $("iframe").remove();
    $("#mortgage-chart-container").append('<canvas id="mortgagePieChart"></canvas>')
 
 }

//Render the Mortgage Chart
function renderMortgageChart(principal,interest){
    
    principal = parseFloat(principal).toFixed(2);
    interest = parseFloat(interest).toFixed(2);
    //TODO: FIX THIS SO IT DOESN'T REQUIRE A TIMEOUT
    setTimeout(()=> {
        var ctx = document.getElementById('mortgagePieChart').getContext('2d');

        var mortgagePieChart = new Chart(ctx,{
            type: 'pie',
            data: {
                datasets: [{
                    data: [principal,interest],
                    backgroundColor: ["#2196F3", "#FF5722"]
                }],
                labels: [
                    'Principal',
                    'Interest'
                ]
            }
        });
    },0.00001)
   
}


function calculateSavings() {
    var startBalance = parseFloat($("#initial-amount-slider").val()); 
    var timeToGrow = parseInt($("#number-year-slider").val()); 
    var monthlyContribution = parseFloat($("#deposit-amount-slider").val());
    var interestRate = parseFloat($("#annual-interest-slider").val()/100);
    
    var frequency = $("#number-year-select").val();
    var frequencyTime =12

    if(frequency == 0){
        frequencyTime = 12;
    }else if(frequency == 1){
        frequencyTime = 1
    }else{
        alert("Something stranged has happened, try  again later");
    }
    

    var totalInterestEarned = 0;
    var totalDeposits = startBalance + (monthlyContribution*timeToGrow*frequencyTime);
    var futureSavings = 0;
    var pvAmount = [];
    var pmtAmount = [];
    
    for(var i=1; i<=timeToGrow; i++){
        //starting amount
        var pvValue = 0;

        //mothly contribution amount
        var pmtValue = 0;
        if(interestRate != 0){
            pvValue = startBalance * Math.pow((1+interestRate/frequencyTime),(i*frequencyTime));
            pmtValue = monthlyContribution * (Math.pow((1+interestRate/frequencyTime),(i*frequencyTime))-1)
            pmtValue = pmtValue/(interestRate/frequencyTime);
        }
        else{
            if(i == 1){
                pvValue = monthlyContribution*frequencyTime;
                pvValue += startBalance;
                
            }else{
                pvValue = parseFloat(pvAmount[i-2]) + monthlyContribution*frequencyTime;
            }
        }
        pvAmount.push(pvValue.toFixed(2));
        pmtAmount.push(pmtValue.toFixed(2));
    }

    destroySavingsChart();
    renderSavingsChart(timeToGrow,pvAmount,pmtAmount);

    if(interestRate != 0){
    totalInterestEarned = parseFloat(pmtAmount[timeToGrow-1]) + parseFloat(pvAmount[timeToGrow-1]);
    totalInterestEarned = totalInterestEarned - ((monthlyContribution*timeToGrow*frequencyTime)) - startBalance;
    futureSavings = parseFloat(pmtAmount[timeToGrow-1]) + parseFloat(pvAmount[timeToGrow-1]);
    }else{
        console.dir(pvAmount);
        console.log('==========================');
        console.dir(pmtAmount);
        totalInterestEarned =  parseFloat(pmtAmount[timeToGrow-1]) + parseFloat(pvAmount[timeToGrow-1]);
        futureSavings = totalDeposits
    }
    $("#total-savings").text(dollarFormat((futureSavings).toFixed(2)));
    $(".total-period").text("earned after " + timeToGrow + (frequency == 0 ? " years":" months"));
    $(".table-savings-deposits").text(dollarFormat((totalDeposits).toFixed(2)));
    $(".table-savings-interest-earned").text(dollarFormat((totalInterestEarned).toFixed(2)));
    $(".table-savings-interest-rate").text((interestRate*100) + " %");
    $(".table-future-savings").text(dollarFormat((futureSavings).toFixed(2)));

}

function destroySavingsChart(){
   $("#savingsLineChart").remove();
   $("iframe").remove();
   $("#savings-chart-container").append('<canvas id="savingsLineChart"></canvas>')

}

//Render the savings Chart
function renderSavingsChart(time,deposits,interests){
    var frequency = $("#number-year-select").val();
    var ctx = document.getElementById('savingsLineChart').getContext('2d');
    var labelGroup = [];
    for(var i=1; i<=time; i++){

        labelPeriod =  (frequency == 0 ? "Year ":"Month ");
        labelGroup.push(labelPeriod + (i));
    }
    var interestRate = parseFloat($("#annual-interest-slider").val()/100);

    if(interestRate != 0){
        var barChartData = {
            labels: labelGroup,
            datasets: [{
                label: 'Initial Amount Gains',
                backgroundColor: "#ffbe00",
                data: deposits
            },
            {
                label: 'Monthly Deposit Gains',
                backgroundColor: "#0041ff",
                data: interests
            }
        ]
        };
    }else{
        var barChartData = {
            labels: labelGroup,
            datasets: [{
                label: 'Total Saved',
                backgroundColor: "#ffbe00",
                data: deposits
            }
        ]
        };
    }

    var savingsLineChart = new Chart(ctx,{
        type: 'bar',
        data: barChartData,
        options: {
            title: {
                display: true,
                text: 'Expected Gain'
            },
            tooltips: {
                mode: 'label',
                
            },
            responsive: true,
            scales: {
                xAxes: [{
                    stacked: true,
                }],
                yAxes: [{
                    stacked: true
                }]
            }
        }
    });
}





//Generate the chart for the page
function renderLoanChart(loanAmount,interestPaid){
    var ctx = document.getElementById('loanChart').getContext('2d');

    loanAmount = parseFloat(loanAmount).toFixed(2)
    interestPaid = parseFloat(interestPaid).toFixed(2);

    var loanChart = new Chart(ctx,{
        type: 'pie',
        data: {
            datasets: [{
                data: [loanAmount,interestPaid],
                backgroundColor: ["#2196F3", "#FF5722"]
            }],
            labels: [
                'Principal',
                'Interest'
            ]
        }
    });
}

//Calculate the loan details
function calculateLoanSummary(){
    var loanSummary = {
        monthlyPayment: 0,
        length :0,
        interestPaid : 0,
        totalPaid: 0
    };

    var frequency = $("#loan-term-select").val();
    var frequencyTime =12

    if(frequency == 0){
        frequencyTime = 12;
    }else if(frequency == 1){
        frequencyTime = 1
    }else{
        alert("Something stranged has happened, try  again later");
    }

    var loanAmount = $("#loan-amount-input").val();
    var loanInterestRate = $("#loan-interest-rate-input").val()/100/frequencyTime;
    var loanTerm = $("#loan-term-input").val()*frequencyTime 

    var mPayment = calculateLoanMonthlyPayment(loanAmount,loanTerm,loanInterestRate);
    var iPaid = calculateLoanTotalInterest(loanAmount,loanTerm,loanInterestRate);
    loanSummary.monthlyPayment = dollarFormat(mPayment);
    loanSummary.interestPaid = dollarFormat(iPaid);
    loanSummary.length = loanTerm;
    loanSummary.totalPaid = dollarFormat(parseFloat(loanAmount)+parseFloat(iPaid))

    $("#loan-monthly-payment").text(loanSummary.monthlyPayment);
    $(".table-loan-total-amount").text(loanSummary.totalPaid);
    $(".table-loan-total-interest-paid").text(loanSummary.interestPaid);
    $(".table-loan-interest-rate").text($("#loan-interest-rate-input").val()+"%");
    $(".table-loan-payment-length").text(loanSummary.length);

    destroyLoanChart();
    renderLoanChart(loanAmount,iPaid)
}

//Calculate monthly payments for loan
function calculateLoanMonthlyPayment(principal,term,rate){
    var monthlyPayment = principal * (rate) * (Math.pow(1 + rate, term)) / (Math.pow(1 + rate, term) - 1);  
    return monthlyPayment;
}


//Calculate the total interest paid on the loans
function calculateLoanTotalInterest(principal,term,rate){
    var monthlyPayment = calculateLoanMonthlyPayment(principal,term,rate);
    var totalPaid = monthlyPayment*term;
    var totalInterest = totalPaid - principal;
    return totalInterest;
}

function destroyLoanChart(){
    $("#loanChart").remove();
    $("iframe").remove();
    $("#loan-chart-container").append('<canvas id="loanChart"></canvas>')
 
}




// FV = Current(1+i)^n
//Formula is P = (A-Fv(r/n))/[(1+(r/n)^(nt)) -1]
function calculateTarget() {

    var targetAmount = parseFloat($("#target-amount-input").val());
    var currentSaved = parseFloat($("#current-saved-input").val());
    var goalRate = parseFloat($("#goal-annual-interest-input").val()/100);
    var time = parseFloat($("#goal-number-year-input").val());
    var frequency = $("#goal-number-year-select").val();
    
    var frequencyTime =0;
    var futureValue = 0
    var numerator = 0;
    var denominator = 0;
    var monthlyTarget = 0;

    if(frequency == 0){
        frequencyTime = 12;
    }else if(frequency == 1){
        frequencyTime = 1
    }else{
        alert("Something stranged has happened, try  again later");
    }

    var totalDeposit = monthlyTarget*frequencyTime*time;
    
    if(currentSaved>targetAmount){
        $("#current-saved-error").text("Amount in savings cannot be more than target amount");
        $("#current-saved-error").removeClass("hidden");
        return;
    }else{
        $("#current-saved-error").addClass("hidden");
    }
    
    if(goalRate != 0){
        futureValue = currentSaved*(Math.pow((1+goalRate),time*frequencyTime));
        numerator = (targetAmount-futureValue)*(goalRate/12);
        denominator = ( Math.pow(1 + (goalRate/12),(time*frequencyTime)) - 1);
        monthlyTarget = numerator/denominator;
        totalDeposit = monthlyTarget*frequencyTime*time;
        
    }else{
        monthlyTarget = (targetAmount - currentSaved)/(frequencyTime * time);
        totalDeposit = targetAmount;
    }
    
    $("#goal-target").text(dollarFormat(monthlyTarget));
    $(".total-target-years").text("every month to reach your target")
    $(".table-target-amount").text(dollarFormat(targetAmount));
    $(".table-target-total-deposits").text(dollarFormat(totalDeposit));
    $(".table-target-payment-length").text(time*frequencyTime);
    renderGoalChart(monthlyTarget);

}

function destroyGoalChart(){
   $("#goalChart").remove();
   $("iframe").remove();
   $("#goal-chart-container").append('<canvas id="goalChart"></canvas>')

}



//Render the savings Chart
function renderGoalChart(monthlyContribution){

    var targetAmount = parseFloat($("#target-amount-input").val());
    var currentSaved = parseFloat($("#current-saved-input").val());
    var goalRate = parseFloat($("#goal-annual-interest-input").val()/100);
    var time = parseFloat($("#goal-number-year-input").val());

    var time = parseFloat($("#goal-number-year-slider").val());
    var frequency = $("#goal-number-year-select").val();
    
    var frequencyTime =0;

    if(frequency == 0){
        frequencyTime = 12;
    }else if(frequency == 1){
        frequencyTime = 1
    }else{
        alert("Something stranged has happened, try  again later");
    }


    var totalInterestEarned = 0;
    var totalDeposits = 0
    var futureSavings = 0;


    var totalDepositCollections = [];
    var totalInterestEarnedCollections = [];

    var savingsStart = currentSaved;

    for(var i=0; i<time; i++){

        totalDeposits += monthlyContribution*frequencyTime;
        var interestEarnedInYear = 0;  
        interestEarnedInYear = savingsStart + (monthlyContribution*frequencyTime) + (savingsStart * goalRate)
        totalDepositCollections.push(totalDeposits.toFixed(2));
        var interestGained = interestEarnedInYear-totalDeposits
        if(goalRate!=0){
        totalInterestEarnedCollections.push(interestGained.toFixed(2));
        }
        savingsStart = interestEarnedInYear;
    }

    destroyGoalChart();

    var labelGroup = [];

    for(var i=1; i<=time; i++){

        labelPeriod =  (frequency == 0 ? "Year ":"Month ");
        labelGroup.push(labelPeriod + (i));
    }
   

    var barChartData = {
        
        labels: labelGroup,
        datasets: [{
            label: 'Yearly Deposit',
            backgroundColor: "#ffbe00",
            data: totalDepositCollections
        },
        {
            label: 'Interest Earned',
            backgroundColor: "#0041ff",
            data: totalInterestEarnedCollections
        }
    ]
        
    };

    var ctx = document.getElementById('goalChart').getContext('2d');
    var goalChart = new Chart(ctx,{
        type: 'bar',
        data: barChartData,
        options: {
            title: {
                display: true,
                text: 'Expected Gain'
            },
            tooltips: {
                mode: 'index',
                intersect: false
            },
            responsive: true,
            scales: {
                xAxes: [{
                    stacked: true,
                }],
                yAxes: [{
                    stacked: true
                }]
            }
        }
    });

}
