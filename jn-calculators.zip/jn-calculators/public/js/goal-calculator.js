$ = jQuery;

$(document).ready(function(){

    renderGoalHtml();
    detectGoalChanges();
    calculateTarget();
});


function renderGoalHtml(){
    $("#goal-inputs").append( generateInputSlider("#goal-inputs","target-amount","Target Amount","0","50000000","1","500000","$"));
    $("#goal-inputs").append( generateInputSlider("#goal-inputs","current-saved","Amount in Savings","0","50000000","1","0","$"));
    $("#goal-inputs").append( generateInputSlider("#goal-inputs","goal-annual-interest","Interest Rate","0","100","0.1","0","%"));
    $("#goal-inputs").append( generateInputSlider("#goal-inputs","goal-number-year","Length of Investment","1","50","1","5","date"));
}


//Listen for changes on savings container
function detectGoalChanges(){
    $(".target-container").change(function(){
        calculateTarget();
    });
}

// FV = Current(1+i)^n
//Formula is P = (A-Fv(r/n))/[(1+(r/n)^(nt)) -1]
function calculateTarget() {

    var targetAmount = parseFloat($("#target-amount-input").val());
    var currentSaved = parseFloat($("#current-saved-input").val());
    var goalRate = parseFloat($("#goal-annual-interest-input").val()/100);
    var time = parseFloat($("#goal-number-year-input").val());
    var frequency = $("#goal-number-year-select").val();
    
    var frequencyTime =0;
    var futureValue = 0
    var numerator = 0;
    var denominator = 0;
    var monthlyTarget = 0;

    if(frequency == 0){
        frequencyTime = 12;
    }else if(frequency == 1){
        frequencyTime = 1
    }else{
        alert("Something stranged has happened, try  again later");
    }

    var totalDeposit = monthlyTarget*frequencyTime*time;
    
    if(currentSaved>targetAmount){
        $("#current-saved-error").text("Amount in savings cannot be more than target amount");
        $("#current-saved-error").removeClass("hidden");
        return;
    }else{
        $("#current-saved-error").addClass("hidden");
    }
    
    if(goalRate != 0){
        futureValue = currentSaved*(Math.pow((1+goalRate),time*frequencyTime));
        numerator = (targetAmount-futureValue)*(goalRate/12);
        denominator = ( Math.pow(1 + (goalRate/12),(time*frequencyTime)) - 1);
        monthlyTarget = numerator/denominator;
        totalDeposit = monthlyTarget*frequencyTime*time;
        
    }else{
        monthlyTarget = (targetAmount - currentSaved)/(frequencyTime * time);
        totalDeposit = targetAmount;
    }
    
    $("#goal-target").text(dollarFormat(monthlyTarget));
    $(".total-target-years").text("every month to reach your target")
    $(".table-target-amount").text(dollarFormat(targetAmount));
    $(".table-target-total-deposits").text(dollarFormat(totalDeposit));
    $(".table-target-payment-length").text(time*frequencyTime);
    renderGoalChart(monthlyTarget);

}

function destroyGoalChart(){
   $("#goalChart").remove();
   $("iframe").remove();
   $("#goal-chart-container").append('<canvas id="goalChart"></canvas>')

}



//Render the savings Chart
function renderGoalChart(monthlyContribution){

    var targetAmount = parseFloat($("#target-amount-input").val());
    var currentSaved = parseFloat($("#current-saved-input").val());
    var goalRate = parseFloat($("#goal-annual-interest-input").val()/100);
    var time = parseFloat($("#goal-number-year-input").val());

    var time = parseFloat($("#goal-number-year-slider").val());
    var frequency = $("#goal-number-year-select").val();
    
    var frequencyTime =0;

    if(frequency == 0){
        frequencyTime = 12;
    }else if(frequency == 1){
        frequencyTime = 1
    }else{
        alert("Something stranged has happened, try  again later");
    }


    var totalInterestEarned = 0;
    var totalDeposits = 0
    var futureSavings = 0;


    var totalDepositCollections = [];
    var totalInterestEarnedCollections = [];

    var savingsStart = currentSaved;

    for(var i=0; i<time; i++){

        totalDeposits += monthlyContribution*frequencyTime;
        var interestEarnedInYear = 0;  
        interestEarnedInYear = savingsStart + (monthlyContribution*frequencyTime) + (savingsStart * goalRate)
        totalDepositCollections.push(totalDeposits.toFixed(2));
        var interestGained = interestEarnedInYear-totalDeposits
        if(goalRate!=0){
        totalInterestEarnedCollections.push(interestGained.toFixed(2));
        }
        savingsStart = interestEarnedInYear;
    }

    destroyGoalChart();

    var labelGroup = [];

    for(var i=1; i<=time; i++){

        labelPeriod =  (frequency == 0 ? "Year ":"Month ");
        labelGroup.push(labelPeriod + (i));
    }
   

    var barChartData = {
        
        labels: labelGroup,
        datasets: [{
            label: 'Yearly Deposit',
            backgroundColor: "#ffbe00",
            data: totalDepositCollections
        },
        {
            label: 'Interest Earned',
            backgroundColor: "#0041ff",
            data: totalInterestEarnedCollections
        }
    ]
        
    };

    var ctx = document.getElementById('goalChart').getContext('2d');
    var goalChart = new Chart(ctx,{
        type: 'bar',
        data: barChartData,
        options: {
            title: {
                display: true,
                text: 'Expected Gain'
            },
            tooltips: {
                mode: 'index',
                intersect: false
            },
            responsive: true,
            scales: {
                xAxes: [{
                    stacked: true,
                }],
                yAxes: [{
                    stacked: true
                }]
            }
        }
    });

}
