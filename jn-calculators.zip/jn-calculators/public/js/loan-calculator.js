$(document).ready(function(){
    renderLoanHtml();
    detectLoanChanges();
    calculateLoanSummary();
});


//Generates the html markup for the view and append them to the container
function renderLoanHtml(){
    $("#loan-inputs").append( generateInputSlider("#loan-inputs","loan-amount","Loan Amount","0","50000000","10000","15000000","$"));
    $("#loan-inputs").append( generateInputSlider("#loan-inputs","loan-interest-rate","Loan Interest Rate","0.1","100",".1","8","%"));
    $("#loan-inputs").append( generateInputSlider("#loan-inputs","loan-term","Loan Term","1","50","1","5","date"));
}


//Generate the chart for the page
function renderLoanChart(loanAmount,interestPaid){
    var ctx = document.getElementById('loanChart').getContext('2d');

    loanAmount = parseFloat(loanAmount).toFixed(2)
    interestPaid = parseFloat(interestPaid).toFixed(2);

    var loanChart = new Chart(ctx,{
        type: 'pie',
        data: {
            datasets: [{
                data: [loanAmount,interestPaid],
                backgroundColor: ["#2196F3", "#FF5722"]
            }],
            labels: [
                'Principal',
                'Interest'
            ]
        }
    });
}


//Listen for changes on loan inputs
function detectLoanChanges(){
    $("#loan-inputs").change(function(){
        calculateLoanSummary();
    });
}


//Calculate the loan details
function calculateLoanSummary(){
    var loanSummary = {
        monthlyPayment: 0,
        length :0,
        interestPaid : 0,
        totalPaid: 0
    };

    var frequency = $("#loan-term-select").val();
    var frequencyTime =12

    if(frequency == 0){
        frequencyTime = 12;
    }else if(frequency == 1){
        frequencyTime = 1
    }else{
        alert("Something stranged has happened, try  again later");
    }

    var loanAmount = $("#loan-amount-input").val();
    var loanInterestRate = $("#loan-interest-rate-input").val()/100/frequencyTime;
    var loanTerm = $("#loan-term-input").val()*frequencyTime 

    var mPayment = calculateLoanMonthlyPayment(loanAmount,loanTerm,loanInterestRate);
    var iPaid = calculateLoanTotalInterest(loanAmount,loanTerm,loanInterestRate);
    loanSummary.monthlyPayment = dollarFormat(mPayment);
    loanSummary.interestPaid = dollarFormat(iPaid);
    loanSummary.length = loanTerm;
    loanSummary.totalPaid = dollarFormat(parseFloat(loanAmount)+parseFloat(iPaid))

    $("#loan-monthly-payment").text(loanSummary.monthlyPayment);
    $(".table-loan-total-amount").text(loanSummary.totalPaid);
    $(".table-loan-total-interest-paid").text(loanSummary.interestPaid);
    $(".table-loan-interest-rate").text($("#loan-interest-rate-input").val()+"%");
    $(".table-loan-payment-length").text(loanSummary.length);

    destroyLoanChart();
    renderLoanChart(loanAmount,iPaid)
}

//Calculate monthly payments for loan
function calculateLoanMonthlyPayment(principal,term,rate){
    var monthlyPayment = principal * (rate) * (Math.pow(1 + rate, term)) / (Math.pow(1 + rate, term) - 1);  
    return monthlyPayment;
}


//Calculate the total interest paid on the loans
function calculateLoanTotalInterest(principal,term,rate){
    var monthlyPayment = calculateLoanMonthlyPayment(principal,term,rate);
    var totalPaid = monthlyPayment*term;
    var totalInterest = totalPaid - principal;
    return totalInterest;
}

function destroyLoanChart(){
    $("#loanChart").remove();
    $("iframe").remove();
    $("#loan-chart-container").append('<canvas id="loanChart"></canvas>')
 
 }