$ = jQuery;

$(document).ready(function(){
    renderSavingsHtml();
    detectSavingsChanges();
    calculateSavings();
});


function renderSavingsHtml(){
    $("#savings-inputs").append( generateInputSlider("#savings-inputs","initial-amount","Starting Amount","0","50000000","1","500000","$"));
    $("#savings-inputs").append( generateInputSlider("#savings-inputs","deposit-amount","Monthly Deposit","0","50000000","1","10000","$"));
    $("#savings-inputs").append( generateInputSlider("#savings-inputs","annual-interest","Interest Rate","0","100","0.1","5","%"));
    $("#savings-inputs").append( generateInputSlider("#savings-inputs","number-year","Length of Investment","1","50","1","5","date"));
}


//Listen for changes on savings container
function detectSavingsChanges(){
    $(".savings-container").change(function(){
        calculateSavings();
    });
}


function calculateSavings() {
    var startBalance = parseFloat($("#initial-amount-slider").val()); 
    var timeToGrow = parseInt($("#number-year-slider").val()); 
    var monthlyContribution = parseFloat($("#deposit-amount-slider").val());
    var interestRate = parseFloat($("#annual-interest-slider").val()/100);
    
    var frequency = $("#number-year-select").val();
    var frequencyTime =12

    if(frequency == 0){
        frequencyTime = 12;
    }else if(frequency == 1){
        frequencyTime = 1
    }else{
        alert("Something stranged has happened, try  again later");
    }
    

    var totalInterestEarned = 0;
    var totalDeposits = startBalance + (monthlyContribution*timeToGrow*frequencyTime);
    var futureSavings = 0;
    var pvAmount = [];
    var pmtAmount = [];
    
    for(var i=1; i<=timeToGrow; i++){
        //starting amount
        var pvValue = 0;

        //mothly contribution amount
        var pmtValue = 0;
        if(interestRate != 0){
            pvValue = startBalance * Math.pow((1+interestRate/frequencyTime),(i*frequencyTime));
            pmtValue = monthlyContribution * (Math.pow((1+interestRate/frequencyTime),(i*frequencyTime))-1)
            pmtValue = pmtValue/(interestRate/frequencyTime);
        }
        else{
            if(i == 1){
                pvValue = monthlyContribution*frequencyTime;
                pvValue += startBalance;
                
            }else{
                pvValue = parseFloat(pvAmount[i-2]) + monthlyContribution*frequencyTime;
            }
        }
        pvAmount.push(pvValue.toFixed(2));
        pmtAmount.push(pmtValue.toFixed(2));
    }

    destroySavingsChart();
    renderSavingsChart(timeToGrow,pvAmount,pmtAmount);

    if(interestRate != 0){
    totalInterestEarned = parseFloat(pmtAmount[timeToGrow-1]) + parseFloat(pvAmount[timeToGrow-1]);
    totalInterestEarned = totalInterestEarned - ((monthlyContribution*timeToGrow*frequencyTime)) - startBalance;
    futureSavings = parseFloat(pmtAmount[timeToGrow-1]) + parseFloat(pvAmount[timeToGrow-1]);
    }else{
        console.dir(pvAmount);
        console.log('==========================');
        console.dir(pmtAmount);
        totalInterestEarned =  parseFloat(pmtAmount[timeToGrow-1]) + parseFloat(pvAmount[timeToGrow-1]);
        futureSavings = totalDeposits
    }
    $("#total-savings").text(dollarFormat((futureSavings).toFixed(2)));
    $(".total-period").text("earned after " + timeToGrow + (frequency == 0 ? " years":" months"));
    $(".table-savings-deposits").text(dollarFormat((totalDeposits).toFixed(2)));
    $(".table-savings-interest-earned").text(dollarFormat((totalInterestEarned).toFixed(2)));
    $(".table-savings-interest-rate").text((interestRate*100) + " %");
    $(".table-future-savings").text(dollarFormat((futureSavings).toFixed(2)));

}

function destroySavingsChart(){
   $("#savingsLineChart").remove();
   $("iframe").remove();
   $("#savings-chart-container").append('<canvas id="savingsLineChart"></canvas>')

}

//Render the savings Chart
function renderSavingsChart(time,deposits,interests){
    var frequency = $("#number-year-select").val();
    var ctx = document.getElementById('savingsLineChart').getContext('2d');
    var labelGroup = [];
    for(var i=1; i<=time; i++){

        labelPeriod =  (frequency == 0 ? "Year ":"Month ");
        labelGroup.push(labelPeriod + (i));
    }
    var interestRate = parseFloat($("#annual-interest-slider").val()/100);

    if(interestRate != 0){
        var barChartData = {
            labels: labelGroup,
            datasets: [{
                label: 'Initial Amount Gains',
                backgroundColor: "#ffbe00",
                data: deposits
            },
            {
                label: 'Monthly Deposit Gains',
                backgroundColor: "#0041ff",
                data: interests
            }
        ]
        };
    }else{
        var barChartData = {
            labels: labelGroup,
            datasets: [{
                label: 'Total Saved',
                backgroundColor: "#ffbe00",
                data: deposits
            }
        ]
        };
    }

    var savingsLineChart = new Chart(ctx,{
        type: 'bar',
        data: barChartData,
        options: {
            title: {
                display: true,
                text: 'Expected Gain'
            },
            tooltips: {
                mode: 'label',
                
            },
            responsive: true,
            scales: {
                xAxes: [{
                    stacked: true,
                }],
                yAxes: [{
                    stacked: true
                }]
            }
        }
    });
}
