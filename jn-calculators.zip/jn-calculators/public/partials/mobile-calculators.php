<div id="calculator-header" class="container-fluid">
    <div class="row">
        <div class="col-md-3 col-xs-6">
            <div id="mortgage-icon" onclick="loadView(`mortgage`)" class="calculator-circle active">
                <i class="fas fa-home"></i>
            </div>
            <h3 class="icon-title text-center">Mortgage <span class="fas fa-info-circle calculator-info hover"></span></h3>
            <h5 class="text-center extra-info">Find your monthly mortage payments.</h5>
        </div>

        <div class="col-md-3 col-xs-6">
            <div id="savings-icon"  onclick="loadView(`savings`)" class="calculator-circle">
                <i class="fas fa-money-bill-alt"></i>
            </div>
            <h3 class="icon-title text-center">Savings <span class="fas fa-info-circle calculator-info hover"></span></h3>
            <h5 class="text-center extra-info">Find out your savings after an elapsed period.</h5>
        </div>

        <div class="col-md-3 col-xs-6">
            <div id="loan-icon" onclick="loadView(`loan`)" class="calculator-circle">
                <i class="fas fa-hand-holding-usd"></i>
            </div>
            <h3 class="icon-title text-center">Loans <span class="fas fa-info-circle calculator-info hover"></span></h3>
            <h5 class="text-center extra-info">Find out the monthly payback on your loans. </h5>
        </div>

        <div class="col-md-3 col-xs-6">
            <div id="target-icon" onclick="loadView(`target`)" class="calculator-circle">
                <i class="fas fa-bullseye"></i>
            </div>
            <h3 class="icon-title text-center">Goals <span class="fas fa-info-circle calculator-info hover"></span></h3>
            <h5 class="text-center extra-info">Find out how long it will take you to reach your target goal.</h5>
        </div>
    </div>
</div>

<div id="mobile-calculator-container" class="mobile">
    <div class="mortgage-container container-fluid">
        <div class="row">
            <h1 class="text-center heading">Mortgage Calculator</h1>
            <hr/>
        </div>
        <div class="row">
            <div id="mortage-inputs" class="col-md-6">

                <div id="nht-container">
                <hr>
                <div class="row">
                    <div class="col-md-8 col-md-offset-3">
                        <label class="checkbox-container">Apply NHT Benefit
                        <input id="applyNht" type="checkbox">
                        <span class="checkmark"></span>
                        </label>
                    </div>
                </div>
                </div>

                <div class="nht">
                </div>
                

            </div>
            <div class="col-md-6">
                <div class="row">
                    <h3 class="text-center">Payment Summary</h3>
                    <h2 id="mortgage-monthly-payment" class="text-center">$5558.32</h2>
                    <h4 class="text-center">per month</h4>
                </div>
                <div class="row">
                    <div id="mortgage-chart-container" class="col-md-8 col-md-offset-2">
                        <canvas id="mortgagePieChart"></canvas>
                    </div>
                </div>
                <div class="col-md-10 col-md-offset-1">
                    <table class="table jn-table">
                        <tbody>
                            <tr>
                                <td><b>Total Loan Amount</b></td>
                                <td><span class="table-mortgage-total-amount">$1,000,000</span></td>
                            </tr>
                            <tr>
                                <td><b>Total Interest Paid</b></td>
                                <td><span class="table-mortgage-interest-paid">$1,000,000</span> @ <span class="table-mortgage-rate"></span></td>
                            </tr>
                            <tr>
                                <td><b>Total # of Payments</b></td>
                                <td><span class="table-mortgage-payment-length"></span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <div class="savings-container container-fluid">
        <div class="row">
        <h1 class="text-center heading">Savings Calculator</h1>
        <hr/>
        </div>
        <div class="row">
            <div id="savings-inputs" class="col-md-6">
            </div>

            <div class="col-md-6">
                <div class="row">
                    <h3 class="text-center">Savings Summary</h3>
                    <h2 id="total-savings" class="text-center">$100000</h2>
                    <h4 class="text-center total-period">after 5 years</h4>
                </div>

                <div class="row">
                    <div id="savings-chart-container" class="col-md-11 col-md-offset-1">
                        <canvas id="savingsLineChart"></canvas>
                    </div>
                </div>
                <div class="col-md-10 col-md-offset-1">
                <table class="table jn-table">
                    <tbody>
                    <tr>
                        <td><b>Total Deposits</b></td>
                        <td><span class="table-savings-deposits">$1,000,000</span></td>
                    </tr>
                    <tr>
                        <td><b>Total Interest Earned</b></td>
                        <td><span class="table-savings-interest-earned">$1,000,000</span> @ <span class="table-savings-interest-rate"></span></td>
                    </tr>
                    <tr>
                        <td><b>Future Savings</b></td>
                        <td><span class="table-future-savings"></span></td>
                    </tr>
                    </tbody>
                </table>
            </div>
            </div>    
        </div>
    </div>


    <div class="loan-container container-fluid">
        <div class="row">
        <h1 class="text-center heading">Loans Calculator</h1>
        <hr/>
        </div>
        <div class="row">
        <div id="loan-inputs" class="col-md-6">
        </div>

        <div class="col-md-6">
            <div class="row">
                <h3 class="text-center">Payment Summary</h3>
                <h2 id="loan-monthly-payment" class="text-center">$5558.32</h2>
                <h4 class="text-center">per month</h4>
            </div>
            <div class="row">
                <div id="loan-chart-container" class="col-md-8 col-md-offset-2">
                    <canvas id="loanChart"></canvas>
                </div>
            </div>
            <div class="col-md-10 col-md-offset-1">
                <table class="table jn-table">
                    <tbody>
                    <tr>
                        <td><b>Loan Amount</b></td>
                        <td><span class="table-loan-total-amount">$1,000,000</span></td>
                    </tr>
                    <tr>
                        <td><b>Total Interest Paid</b></td>
                        <td><span class="table-loan-total-interest-paid">$1,000,000</span> @ <span class="table-loan-interest-rate"></span></td>
                    </tr>
                    <tr>
                        <td><b>Total # of Payments</b></td>
                        <td><span class="table-loan-payment-length"></span></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
        </div>
    </div> 

    <div class="target-container container-fluid">
        <div class="row">
        <h1 class="text-center heading">Savings Goal Calculator</h1>
        <hr/>
        </div>
        <div class="row">
            <div id="goal-inputs" class="col-md-6">
            

            </div>
        


            <div class="col-md-6">
                <div class="row">
                    <h3 class="text-center">You need to save approximately</h3>
                    <h2 id="goal-target" class="text-center">$100000</h2>
                    <h4 class="text-center total-target-years">every month for 5 years</h4>
                </div>

                <div class="row">
                    <div id="goal-chart-container" class="col-md-11 col-md-offset-1">
                        <canvas id="goalChart"></canvas>
                    </div>
                </div>
                <div class="col-md-10 col-md-offset-1">
                    <table class="table jn-table">
                        <tbody>
                            <tr>
                                <td><b>Target Amount</b></td>
                                <td><span class="table-target-amount">$1,000,000</span></td>
                            </tr>
                            <tr>
                                <td><b>Total Amount Deposited</b></td>
                                <td><span class="table-target-total-deposits">$1,000,000</span></td>
                            </tr>
                            <tr>
                                <td><b>Total # of Deposits</b></td>
                                <td><span class="table-target-payment-length"></span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>    
        </div>
    </div>


<script type="text/javascript"> 
var pathToScripts = WPURLS.plugin_url + "/public/js/mobile-calculator.js";

var dynamicScript = document.createElement('script');
dynamicScript.setAttribute('src',pathToScripts);
document.head.appendChild(dynamicScript);
</script>
</div>


