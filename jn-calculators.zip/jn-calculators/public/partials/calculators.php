<div id="calculator-header" class="container-fluid">
    <div class="row">
        <div class="col-md-3">
            <div id="mortgage-icon" onclick="loadCalculator(`mortgage`)" class="calculator-circle active">
                <i class="fas fa-home"></i>
            </div>
            <h3 class="icon-title text-center">Mortgage <span class="fas fa-info-circle calculator-info hover"></span></h3>
            <h5 class="text-center extra-info">Find your monthly mortage payments.</h5>
        </div>

        <div class="col-md-3">
            <div id="savings-icon"  onclick="loadCalculator(`savings`)" class="calculator-circle">
                <i class="fas fa-money-bill-alt"></i>
            </div>
            <h3 class="icon-title text-center">Savings <span class="fas fa-info-circle calculator-info hover"></span></h3>
            <h5 class="text-center extra-info">Find out your savings after an elapsed period.</h5>
        </div>

        <div class="col-md-3">
            <div id="loans-icon" onclick="loadCalculator(`loans`)" class="calculator-circle">
                <i class="fas fa-hand-holding-usd"></i>
            </div>
            <h3 class="icon-title text-center">Loans <span class="fas fa-info-circle calculator-info hover"></span></h3>
            <h5 class="text-center extra-info">Find out the monthly payback on your loans. </h5>
        </div>

        <div class="col-md-3">
            <div id="goal-icon" onclick="loadCalculator(`goal`)" class="calculator-circle">
                <i class="fas fa-bullseye"></i>
            </div>
            <h3 class="icon-title text-center">Goals <span class="fas fa-info-circle calculator-info hover"></span></h3>
            <h5 class="text-center extra-info">Find out how long it will take you to reach your target goal.</h5>
        </div>
    </div>
</div>

<div id="calculator-container">
</div>