<div class="savings-container container-fluid">
    <div class="row">
       <h1 class="text-center heading">Savings Calculator</h1>
       <hr/>
    </div>
    <div class="row">
        <div id="savings-inputs" class="col-md-6">
        </div>

        <div class="col-md-6">
            <div class="row">
                <h3 class="text-center">Savings Summary</h3>
                <h2 id="total-savings" class="text-center">$100000</h2>
                <h4 class="text-center total-period">after 5 years</h4>
            </div>

            <div class="row">
                <div id="savings-chart-container" class="col-md-11 col-md-offset-1">
                    <canvas id="savingsLineChart"></canvas>
                </div>
            </div>
            <div class="col-md-10 col-md-offset-1">
             <table class="table jn-table">
                <tbody>
                   <tr>
                      <td><b>Total Deposits</b></td>
                      <td><span class="table-savings-deposits">$1,000,000</span></td>
                   </tr>
                   <tr>
                      <td><b>Total Interest Earned</b></td>
                      <td><span class="table-savings-interest-earned">$1,000,000</span> @ <span class="table-savings-interest-rate"></span></td>
                   </tr>
                   <tr>
                      <td><b>Future Savings</b></td>
                      <td><span class="table-future-savings"></span></td>
                   </tr>
                </tbody>
             </table>
          </div>
        </div>    
    </div>
</div>

<script type="text/javascript"> 
var pathToScripts = WPURLS.plugin_url + "/public/js/savings-calculator.js";

var dynamicScript = document.createElement('script');
dynamicScript.setAttribute('src',pathToScripts);
document.head.appendChild(dynamicScript);
</script> 
