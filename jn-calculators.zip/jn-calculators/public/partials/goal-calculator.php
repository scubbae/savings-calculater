<div class="target-container container-fluid">
    <div class="row">
       <h1 class="text-center heading">Savings Goal Calculator</h1>
       <hr/>
    </div>
    <div class="row">
        <div id="goal-inputs" class="col-md-6">
        

        </div>
    


        <div class="col-md-6">
            <div class="row">
                <h3 class="text-center">You need to save approximately</h3>
                <h2 id="goal-target" class="text-center">$100000</h2>
                <h4 class="text-center total-target-years">every month for 5 years</h4>
            </div>

            <div class="row">
                <div id="goal-chart-container" class="col-md-11 col-md-offset-1">
                    <canvas id="goalChart"></canvas>
                </div>
            </div>
            <div class="col-md-10 col-md-offset-1">
                <table class="table jn-table">
                    <tbody>
                        <tr>
                            <td><b>Target Amount</b></td>
                            <td><span class="table-target-amount">$1,000,000</span></td>
                        </tr>
                        <tr>
                            <td><b>Total Amount Deposited</b></td>
                            <td><span class="table-target-total-deposits">$1,000,000</span></td>
                        </tr>
                        <tr>
                            <td><b>Total # of Deposits</b></td>
                            <td><span class="table-target-payment-length"></span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>    
    </div>
</div>

<script type="text/javascript"> 
var pathToScripts = WPURLS.plugin_url + "/public/js/goal-calculator.js";

var dynamicScript = document.createElement('script');
dynamicScript.setAttribute('src',pathToScripts);
document.head.appendChild(dynamicScript);
</script> 
