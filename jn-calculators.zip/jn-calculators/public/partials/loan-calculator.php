<div class="mortgage-container container-fluid">
    <div class="row">
       <h1 class="text-center heading">Loans Calculator</h1>
       <hr/>
    </div>
    <div class="row">
       <div id="loan-inputs" class="col-md-6">
       </div>

       <div class="col-md-6">
          <div class="row">
             <h3 class="text-center">Payment Summary</h3>
             <h2 id="loan-monthly-payment" class="text-center">$5558.32</h2>
             <h4 class="text-center">per month</h4>
          </div>
          <div class="row">
             <div id="loan-chart-container" class="col-md-8 col-md-offset-2">
                <canvas id="loanChart"></canvas>
             </div>
          </div>
          <div class="col-md-10 col-md-offset-1">
             <table class="table jn-table">
                <tbody>
                   <tr>
                      <td><b>Loan Amount</b></td>
                      <td><span class="table-loan-total-amount">$1,000,000</span></td>
                   </tr>
                   <tr>
                      <td><b>Total Interest Paid</b></td>
                      <td><span class="table-loan-total-interest-paid">$1,000,000</span> @ <span class="table-loan-interest-rate"></span></td>
                   </tr>
                   <tr>
                      <td><b>Total # of Payments</b></td>
                      <td><span class="table-loan-payment-length"></span></td>
                   </tr>
                </tbody>
             </table>
          </div>
       </div>
    </div>
</div> 

<script type="text/javascript"> 
var pathToScripts = WPURLS.plugin_url + "/public/js/loan-calculator.js";

var dynamicScript = document.createElement('script');
dynamicScript.setAttribute('src',pathToScripts);
document.head.appendChild(dynamicScript);
</script> 
