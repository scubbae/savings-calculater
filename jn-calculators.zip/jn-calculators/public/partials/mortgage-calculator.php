<div class="mortgage-container container-fluid">
    <div class="row">
        <h1 class="text-center heading">Mortgage Calculator</h1>
        <hr/>
    </div>
    <div class="row">
        <div id="mortage-inputs" class="col-md-6">

            <div id="nht-container">
               <hr>
               <div class="row">
                  <div class="col-md-8 col-md-offset-3">
                     <label class="checkbox-container">Apply NHT Benefit
                     <input id="applyNht" type="checkbox">
                     <span class="checkmark"></span>
                     </label>
                  </div>
               </div>
            </div>

            <div class="nht">
            </div>
            

        </div>
        <div class="col-md-6">
            <div class="row">
                <h3 class="text-center">Payment Summary</h3>
                <h2 id="mortgage-monthly-payment" class="text-center">$5558.32</h2>
                <h4 class="text-center">per month</h4>
            </div>
            <div class="row">
                <div id="mortgage-chart-container" class="col-md-8 col-md-offset-2">
                    <canvas id="mortgagePieChart"></canvas>
                </div>
            </div>
            <div class="col-md-10 col-md-offset-1">
                <table class="table jn-table">
                    <tbody>
                        <tr>
                            <td><b>Total Loan Amount</b></td>
                            <td><span class="table-mortgage-total-amount">$1,000,000</span></td>
                        </tr>
                        <tr>
                            <td><b>Total Interest Paid</b></td>
                            <td><span class="table-mortgage-interest-paid">$1,000,000</span> @ <span class="table-mortgage-rate"></span></td>
                        </tr>
                        <tr>
                            <td><b>Total # of Payments</b></td>
                            <td><span class="table-mortgage-payment-length"></span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript"> 
var pathToScripts = WPURLS.plugin_url + "/public/js/mortgage-calculator.js";

var dynamicScript = document.createElement('script');
dynamicScript.setAttribute('src',pathToScripts);
document.head.appendChild(dynamicScript);
</script> 
