<?php

class Jn_Calculators_Public {

	public function __construct( $plugin_name, $version ) {
		$this->plugin_name = $plugin_name;
		$this->version = $version;
	}

	public function enqueue_styles() {
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/jn-calculators-public.css', array(), $this->version, 'all' );
    	wp_enqueue_style( 'load-fa', 'https://use.fontawesome.com/releases/v5.6.1/css/all.css');
	}

	public function enqueue_scripts() {
		wp_enqueue_script('jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js', array(), null, true);
		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/jn-calculators-public.js', array( 'jquery' ), $this->version, false );
		wp_localize_script($this->plugin_name, 'WPURLS', array( 'plugin_url' => get_option('siteurl') . '/wp-content/plugins/jn-calculators' ));
		wp_enqueue_script('chart_js', 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js', array(), null, true);
	}

	
}
