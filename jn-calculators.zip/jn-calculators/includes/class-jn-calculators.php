<?php


class Jn_Calculators {

	protected $loader;
	protected $plugin_name;
	protected $version;

	public function __construct() {
		if ( defined( 'PLUGIN_NAME_VERSION' ) ) {
			$this->version = PLUGIN_NAME_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'jn-calculators';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();
		add_shortcode( 'jn_calculator', array($this, 'choose_calculator') );
		add_shortcode( 'jn_calculator_mobile', array($this, 'choose_mobile_calculator') );
	}

	
	public function choose_calculator(){
		$this->loadCalculator();
	}

	public function choose_mobile_calculator(){
		$this->loadMobileCalculator();
	}


	private function load_dependencies() {
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-jn-calculators-loader.php';
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-jn-calculators-i18n.php';
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-jn-calculators-admin.php';
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-jn-calculators-public.php';
		$this->loader = new Jn_Calculators_Loader();
	}

	
	private function set_locale() {
		$plugin_i18n = new Jn_Calculators_i18n();
		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );
	}


	private function define_admin_hooks() {
		$plugin_admin = new Jn_Calculators_Admin( $this->get_plugin_name(), $this->get_version() );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );

	}


	private function define_public_hooks() {
		$plugin_public = new Jn_Calculators_Public( $this->get_plugin_name(), $this->get_version() );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );
	}


	
	public function run() {
		$this->loader->run();
	}

	
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	
	public function get_loader() {
		return $this->loader;
	}

	public function get_version() {
		return $this->version;
	}

	public function loadCalculator(){
		$calculatorPath = plugin_dir_path( dirname(__FILE__) ) . 'public/partials/calculators.php';
		require_once ($calculatorPath);
	}

	public function loadMobileCalculator(){
		$mobileCalculatorPath = plugin_dir_path( dirname(__FILE__) ) . 'public/partials/mobile-calculators.php';
		require_once ($mobileCalculatorPath);
	}
	

}
