<?php


class Jn_Calculators_i18n {

	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'jn-calculators',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
