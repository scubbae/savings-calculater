<?php


class Jn_Calculators_Activator {

	public static function activate() {

	}

}
