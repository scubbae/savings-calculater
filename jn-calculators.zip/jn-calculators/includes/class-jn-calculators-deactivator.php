<?php


class Jn_Calculators_Deactivator {

	public static function deactivate() {

	}

}
