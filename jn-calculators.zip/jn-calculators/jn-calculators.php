<?php

/**
* The plugin bootstrap file
*
* This file is read by WordPress to generate the plugin information in the plugin
* admin area. This file also includes all of the dependencies used by the plugin,
* registers the activation and deactivation functions, and defines a function
* that starts the plugin.
*
* @link              https://johngordon.co
* @since             1.0.0
* @package           Jn_Calculators
*
* @wordpress-plugin
* Plugin Name:       Jn Calculators
* Plugin URI:        https://jngroup.com
* Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
* Version:           1.0.0
* Author:            John Gordon
* Author URI:        https://johngordon.co
* License:           GPL-2.0+
* License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
* Text Domain:       jn-calculators
* Domain Path:       /languages
*/


if ( ! defined( 'WPINC' ) ) {
	die;
}

define( 'PLUGIN_NAME_VERSION', '1.0.0' );


function activate_jn_calculators() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-jn-calculators-activator.php';
	Jn_Calculators_Activator::activate();
}


function deactivate_jn_calculators() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-jn-calculators-deactivator.php';
	Jn_Calculators_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_jn_calculators' );
register_deactivation_hook( __FILE__, 'deactivate_jn_calculators' );


require plugin_dir_path( __FILE__ ) . 'includes/class-jn-calculators.php';


function run_jn_calculators() {

	$plugin = new Jn_Calculators();
	$plugin->run();

}

run_jn_calculators();
