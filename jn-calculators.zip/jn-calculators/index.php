<?php // Silence is golden



